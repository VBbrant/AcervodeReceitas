<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Captura os dados do formulário
    $id_funcionario = $_POST['id-funcionario'];
    $nome_funcionario = $_POST['nome-funcionario'];
    $rg = $_POST['rg'];
    $data_admissao = $_POST['data-admissao'];
    $salario = $_POST['salario'];
    $cargo = $_POST['cargo'];
    $nome_fantasia = $_POST['nome-fantasia'];

    // Aqui você pode adicionar lógica para salvar os dados no banco de dados
    // Exemplo:
    // $sql = "INSERT INTO funcionarios (id, nome, rg, data_admissao, salario, cargo, nome_fantasia) VALUES ('$id_funcionario', '$nome_funcionario', '$rg', '$data_admissao', '$salario', '$cargo', '$nome_fantasia')";
    
    // Exibir mensagem de sucesso (apenas para fins de exemplo)
    echo "<script>alert('Funcionário incluído com sucesso!');</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Incluir Funcionário</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            background-image: url('https://placehold.co/800x800');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            filter: sepia(0.5);
        }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen bg-opacity-50">
    <div class="bg-white bg-opacity-75 p-8 rounded-lg shadow-lg w-full max-w-lg">
        <h1 class="text-4xl font-bold text-center mb-8">Incluir Funcionário</h1>
        <form method="POST" action="">
            <div class="mb-4">
                <label for="id-funcionario" class="block text-sm font-medium text-gray-700">Id funcionário</label>
                <input type="text" name="id-funcionario" id="id-funcionario" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" value="0001">
            </div>
            <div class="mb-4">
                <label for="nome-funcionario" class="block text-sm font-medium text-gray-700">Nome funcionário</label>
                <input type="text" name="nome-funcionario" id="nome-funcionario" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" value="Nome">
            </div>
            <div class="mb-4">
                <label for="rg" class="block text-sm font-medium text-gray-700">Rg</label>
                <input type="text" name="rg" id="rg" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" value="0000-000">
            </div>
            <div class="mb-4">
                <label for="data-admissao" class="block text-sm font-medium text-gray-700">Data de admissão</label>
                <input type="date" name="data-admissao" id="data-admissao" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" value="2021-10-30">
            </div>
            <div class="mb-4">
                <label for="salario" class="block text-sm font-medium text-gray-700">Salário</label>
                <input type="text" name="salario" id="salario" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" value="R$ 10000,00">
            </div>
            <div class="mb-4">
                <label for="cargo" class="block text-sm font-medium text-gray-700">Cargo</label>
                <select name="cargo" id="cargo" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                    <option>ADMINISTRADOR</option>
                </select>
            </div>
            <div class="mb-4">
                <label for="nome-fantasia" class="block text-sm font-medium text-gray-700">Nome fantasia</label>
                <input type="text" name="nome-fantasia" id="nome-fantasia" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" value="Nome">
            </div>
            <div class="flex justify-center">
                <button type="submit" class="bg-black text-white py-2 px-4 rounded-md">Incluir</button>
            </div>
        </form>
    </div>
</body>
</html>

